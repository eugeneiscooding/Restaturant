//
//  ContentView.swift
//  Restaturant
//
//  Created by Kavsoft on 05/03/20.
//  Copyright © 2020 Kavsoft. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        NavigationView{
            
            Home()
            .navigationBarTitle("")
            .navigationBarHidden(true)
        }
        
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct Home : View {
    
    @State var user = ""
    @State var pass = ""
    @State var show = false
    
    var body : some View{
        
        ZStack{
            
            NavigationLink(destination: Register(show: self.$show), isActive: self.$show) {
                
                Text("")
            }
            
            VStack{
                
                HStack{
                    
                    Spacer()
                    
                    Image("shape")
                    
                }
                
                VStack{
                    
                    Image("logo")
                    Image("name").padding(.top,10)
                    
                }.offset(y: -122)
                .padding(.bottom,-132)
                
                VStack(spacing: 20){
                    
                    Text("Hello").font(.title).fontWeight(.bold)
                    
                    Text("Sign Into Your Account").fontWeight(.bold)
                    
                    CustomTF(value: self.$user, isemail: true)
                    
                    CustomTF(value: self.$pass, isemail: false)
                    
                    HStack{
                        
                        Spacer()
                        
                        Button(action: {
                            
                        }) {
                            
                            Text("Forget Password ?").foregroundColor(Color.black.opacity(0.1))
                        }
                    }
                    
                    Button(action: {
                        
                    }) {
                        
                        Text("Login")
                            .frame(width: UIScreen.main.bounds.width - 100)
                            .padding(.vertical)
                            .foregroundColor(.white)
                        
                    }.background(Color("Color1"))
                    .clipShape(Capsule())
                    
                    
                    Text("Or Login Using Social Media").fontWeight(.bold)
                    
                    SocialMedia()
                    
                }.padding()
                .background(Color.white)
                .cornerRadius(5)
                .padding()
                
                HStack{
                    
                    Text("Don't Have an Account ?")
                    
                    Button(action: {
                        
                        self.show.toggle()
                        
                    }) {
                        
                        Text("Register Now").foregroundColor(Color("Color1"))
                    }
                    
                }.padding(.top)
                
                Spacer(minLength: 0)
                
            }.edgesIgnoringSafeArea(.top)
            .background(Color("Color").edgesIgnoringSafeArea(.all))
        }
    }
}

struct SocialMedia : View {
    
    var body : some View{
        
        HStack(spacing: 40){
            
            Button(action: {
                
            }) {
                
                Image("fb").renderingMode(.original)
            }
            
            Button(action: {
                
            }) {
                
                Image("twitter").renderingMode(.original)
            }
        }
    }
}

struct CustomTF : View {
    
    @Binding var value : String
    var isemail = false
    var reenter = false
    
    var body : some View{
        
        VStack(spacing: 8){
            
            HStack{
                
                Text(self.isemail ? "Email ID" : self.reenter ? "Re-Enter" : "Password").foregroundColor(Color.black.opacity(0.1))
                
                Spacer()
            }
            
            
            
            HStack{
                
                if self.isemail{
                    
                    TextField("", text: self.$value)
                }
                else{
                    
                    SecureField("", text: self.$value)
                }
                
                
                Button(action: {
                    
                }) {
                    
                    Image(systemName: self.isemail ? "envelope.fill" : "eye.slash.fill").foregroundColor(Color("Color1"))
                }
            }
            
            Divider()
        }
    }
}

struct Register : View {
    
    @State var user = ""
    @State var pass = ""
    @State var repass = ""
    @State var agree = false
    @Binding var show : Bool
    
    var body : some View{
        
        ZStack(alignment: .topLeading) {
            
            VStack{
                
                HStack{
                    
                    Spacer()
                    
                    Image("shape")
                    
                }
                
                VStack{
                    
                    Image("logo")
                    Image("name").padding(.top,10)
                    
                }.offset(y: -122)
                .padding(.bottom,-132)
                
                VStack(spacing: 20){
                    
                    Text("Hello").font(.title).fontWeight(.bold)
                    
                    Text("Sign Into Your Account").fontWeight(.bold)
                    
                    CustomTF(value: self.$user, isemail: true)
                    
                    CustomTF(value: self.$pass, isemail: false)
                    
                    CustomTF(value: self.$repass, isemail: false,reenter: true)
                    
                    HStack{
                        
                        Button(action: {
                            
                            self.agree.toggle()
                            
                        }) {
                            
                            ZStack{
                                
                                Circle().fill(Color.black.opacity(0.05)).frame(width: 20, height: 20)
                                
                                if self.agree{
                                    
                                    Image("check").resizable().frame(width: 10, height: 10)
                                        .foregroundColor(Color("Color1"))
                                }
                            }
                            
                        }
                        
                        Text("I Read And Agree The Terms And Conditions").font(.caption)
                            .foregroundColor(Color.black.opacity(0.1))
                        
                        Spacer()

                    }
                    
                    Button(action: {
                        
                    }) {
                        
                        Text("Register Now")
                            .frame(width: UIScreen.main.bounds.width - 100)
                            .padding(.vertical)
                            .foregroundColor(.white)
                        
                    }.background(Color("Color1"))
                    .clipShape(Capsule())
                    
                    
                    Text("Or Register Using Social Media").fontWeight(.bold)
                    
                    SocialMedia()
                    
                }.padding()
                .background(Color.white)
                .cornerRadius(5)
                .padding()
                
                
                Spacer(minLength: 0)
                
            }.edgesIgnoringSafeArea(.top)
            .background(Color("Color").edgesIgnoringSafeArea(.all))
            
            Button(action: {
                
                self.show.toggle()
                
            }) {
                
                Image(systemName: "arrow.left").resizable().frame(width: 18, height: 15).foregroundColor(.black)
                
            }.padding()
            
        }.navigationBarTitle("")
        .navigationBarHidden(true)
    }
}
